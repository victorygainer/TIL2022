INSERT INTO article(id, title, content) VALUES (1, '홍길동', '천재');
INSERT INTO article(id, title, content) VALUES (2, '임꺽정', '처언재');
INSERT INTO article(id, title, content) VALUES (3, '장길산', '처어언재');
INSERT INTO article(id, title, content) VALUES (4, '일지매', '바보');