package com.tjoeun.springBoot.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tjoeun.springBoot.dto.ArticleForm;
import com.tjoeun.springBoot.entity.Article;
import com.tjoeun.springBoot.repository.ArticleRepository;

import lombok.extern.slf4j.Slf4j;

//	@RestController 어노테이션은 REST api용 컨트롤러로 사용됨을 의미한다.
//	뷰 템플릿 형식이 아닌 json 형식의 데이터를 반환한다.
@RestController
@Slf4j
public class ArticleApiController {

	@Autowired
	private ArticleRepository articleRepository;
	
	@GetMapping("/api/articles")
	public List<Article> index() {
		log.info("ArticleApiController의 index() 메소드 실행");
		return articleRepository.findAll();
	}
	
	@GetMapping("/api/articles/{id}")
	public Article show(@PathVariable Long id) {
		log.info("ArticleApiController의 show() 메소드 실행");
		return articleRepository.findById(id).orElse(null);
	}
	
	@PostMapping("/api/articles")
//	form에서 데이터를 받아올 때는 커맨드 객체로 그냥 받으면 되지만 REST api에서 json으로 
//	던지는 데이터를 받을 때는 body 부분에 담겨오는 데이터를 받아야 하므로 커맨드 객체에서
//	@RequestBody 어노테이션을 붙여서 받아야 한다.
	public void create(@RequestBody ArticleForm form) {
		log.info(form.toString());
	}
	
}
