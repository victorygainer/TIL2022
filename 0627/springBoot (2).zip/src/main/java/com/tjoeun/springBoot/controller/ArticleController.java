package com.tjoeun.springBoot.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.tjoeun.springBoot.dto.ArticleForm;

@Controller
public class ArticleController {

	@GetMapping("/articles/new")
	public String newArticleForm() {
		System.out.println("ArticleController의 newArticleForm() 메소드 실행");
		return "articles/new";
	}
	
	@PostMapping("/articles/create")
//	form에서 넘어오는 데이터는 커맨드 객체로 받는다.
	public String createArticle(ArticleForm form) {
		System.out.println("ArticleController의 createArticle() 메소드 실행");
		System.out.println(form);
		return "";
	}
	
}
