package com.tjoeun.springBoot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tjoeun.springBoot.dto.CommentVO;
import com.tjoeun.springBoot.repository.ArticleRepository;
import com.tjoeun.springBoot.repository.CommentRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CommentService {

//	ArticleRepository와 CommentRepository 클래스의 메소드를 사용하기 위해 ArticleRepository 클래스와
//	CommentRepository 클래스의 bean을 가져온다.
	@Autowired
	private ArticleRepository articleRepository;
	@Autowired
	private CommentRepository commentRepository;
	
//	댓글 목록 조회
	public List<CommentVO> comments(Long articleId) {
		log.info("CommentService의 comments() 메소드 실행");
		
		return null;
	}
	
	
}



