
public interface Health extends Body, Food {
}
