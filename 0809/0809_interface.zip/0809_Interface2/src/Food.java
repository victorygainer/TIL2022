
public interface Food {
	String eat();
}
