
public interface Body {
	String weight();
	String height();
	
}
