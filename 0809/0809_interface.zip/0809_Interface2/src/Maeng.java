
public class Maeng implements Health  {

	@Override
	public String weight() {
		return "90kg";
	}

	@Override
	public String height() {
		return "171cm";
	}

	@Override
	public String eat() {
		return "a lot";
	}

}
