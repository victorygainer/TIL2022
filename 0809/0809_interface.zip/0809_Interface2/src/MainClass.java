
public class MainClass {
	public static void main(String[] args) {
		Joe joe = new Joe();
		System.out.println("키: " + joe.height());
		System.out.println("몸무게:" + joe.weight());
	
		Maeng maeng = new Maeng();
		System.out.println(maeng.weight());
		System.out.println(maeng.height());
		System.out.println(maeng.eat());
	}
}
