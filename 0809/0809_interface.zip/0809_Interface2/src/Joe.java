
public class Joe implements Body {

	@Override
	public String weight() {
		return "170";
	}

	@Override
	public String height() {
		return "70";
	}
}
