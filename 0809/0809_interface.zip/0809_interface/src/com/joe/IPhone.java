package com.joe;

public class IPhone implements Phone {
		
	@Override
	public String getManufacturer() {
		return "Apple";
	}
	
	@Override
	public String getOS() {
		return "MacOS";
	}
	
}
