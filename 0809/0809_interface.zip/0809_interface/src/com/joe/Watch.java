package com.joe;

public interface Watch {
	String getAppearance();
}
