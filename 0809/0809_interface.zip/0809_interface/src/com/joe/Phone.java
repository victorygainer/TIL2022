package com.joe;

public interface Phone {
	int version = 13;
	
	String getManufacturer();
	String getOS();
	
	default void printRing() {
		System.out.println("Sound : Ring Ring~~ ");
	}
	
	private void printInfo() {
		System.out.println("Print Information");
	}
	
	static void pringUser(String user) {
		System.out.println("User : " + user);
	}
	
}

