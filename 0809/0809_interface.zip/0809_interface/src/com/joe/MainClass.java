package com.joe;

public class MainClass {
	public static void main(String[] args) {
		Phone galaxy = new Galaxy();
		Phone iphone = new IPhone();
		
		System.out.println(galaxy.getManufacturer());
		System.out.println(galaxy.getOS());
		galaxy.printRing();
		
		System.out.println(iphone.getManufacturer());
		System.out.println(iphone.getOS());
		iphone.printRing();
 
		
		
		Phone.pringUser("Joe");
		
		
	}
}
