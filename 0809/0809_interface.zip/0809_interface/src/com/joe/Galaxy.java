package com.joe;

public class Galaxy implements Phone {
	@Override
	public String getManufacturer() {
		return "Samsung";
	}
	
	@Override
	public String getOS() {
		return "Android";
	}
	
	@Override
	public void printRing() {
		System.out.println("Sound : Ring~~~");
	}
}
