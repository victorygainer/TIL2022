package com.joe;

public interface Device extends Phone, Watch {

}
