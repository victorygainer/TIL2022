package com.joe;

public class Machine implements Device {
	@Override
	public String getManufacturer() {
		return null;
	}

	@Override
	public String getOS() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getAppearance() {
		// TODO Auto-generated method stub
		return null;
	}
}
