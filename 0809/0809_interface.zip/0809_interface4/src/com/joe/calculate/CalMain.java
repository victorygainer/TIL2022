package com.joe.calculate;

import java.util.Scanner;

public class CalMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		Calculate cal = new Calculator();
		System.out.println("계산 할 정수 두 개를 띄어서 입력해주세요: ");
		
		try {
			int x = scanner.nextInt();
			int y = scanner.nextInt();
			System.out.println("덧셈: " + cal.add(x, y));
			System.out.println("뺄셈: " + cal.sub(x, y));
			System.out.println("곱셈: " + cal.mul(x, y));
			System.out.println("나눗셈: " + cal.div(x, y));
		} catch (Exception e) {
			System.out.println("올바르지 않은 입력 값입니다.");
		}
	}
}
