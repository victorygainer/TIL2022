
public class StackApp implements Stack {
	private int top;
	private int size;
	private String str[];
	
	public StackApp(int size) {
		top = -1;
		this.size = size;
		str = new String[this.size];
	}

	@Override
	public int length() {
		// TODO Auto-generated method stub
		return top;
	}

	@Override
	public int capacity() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public String pop() {
		if(length() == -1) {
			System.out.println("스택에 데이터가 없습니다");
		}
		return str[--top];
	}

	@Override
	public boolean push(String pustr) {
		if(top == (this.size - 1)) {
			System.out.println("스택이 꽉 차서 푸시 불가!");
			return false;
		} else {
			str[++top] = pustr;
		}
		return true;
	}
	
	public void printStack() {
		if(length() == -1) {
			System.out.println("스택에 데이터가 없습니다.");
		} else {
			System.out.println("스택에 저장된 모든 문자열 팝: ");
			for (int i = 0 ; i<=top ; i++) {
				System.out.println(str[i] + "");
			}
			System.out.println();
		}
	}

}
