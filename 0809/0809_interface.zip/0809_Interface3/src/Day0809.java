
public class Day0809 implements Eat {

	@Override
	public String breakfast() {
		return "굶음";
	}

	@Override
	public String Lunch() {
		return "도시락";
	}

	@Override
	public String Dinner() {
		return "간편식";
	}

}
