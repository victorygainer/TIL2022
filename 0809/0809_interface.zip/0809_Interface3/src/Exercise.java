
public interface Exercise {
	String morningExercise();
	String afternoonExercise();
	String eveningExercise();
}
