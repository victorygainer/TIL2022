
public class Day0808 implements Eat, Exercise {

	@Override
	public String morningExercise() {
		return "yoga";
	}

	@Override
	public String afternoonExercise() {
		return "none";
	}

	@Override
	public String eveningExercise() {
		return "none";
	}

	@Override
	public String breakfast() {
		return "yogurt";
	}

	@Override
	public String Lunch() {
		return "curry";
	}

	@Override
	public String Dinner() {
		return "Fried chicken";
	}

}
