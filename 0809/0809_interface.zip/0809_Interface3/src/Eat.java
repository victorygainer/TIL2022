
public interface Eat {
	String breakfast();
	String Lunch();
	String Dinner();
}
