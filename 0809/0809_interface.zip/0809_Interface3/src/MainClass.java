
public class MainClass {
	public static void main(String[] args) {
		Day0809 day = new Day0809();
		System.out.println("아침: " + day.breakfast());
		System.out.println("점심: " + day.Lunch());
		System.out.println("저녁: " + day.Dinner());
		
		Day0808 day0808 = new Day0808();
		System.out.println("운동(아침): " + day0808.morningExercise());
		System.out.println("식사(아침): " + day0808.breakfast());
		
	}
}
