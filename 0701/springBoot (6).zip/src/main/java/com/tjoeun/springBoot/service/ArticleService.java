package com.tjoeun.springBoot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tjoeun.springBoot.dto.ArticleForm;
import com.tjoeun.springBoot.entity.Article;
import com.tjoeun.springBoot.repository.ArticleRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
//	@Service 어노테이션을 붙여준 클래스는 springBoot가 서비스로 인식해서 자동으로 bean을 생성해 등록한다.
@Service
public class ArticleService {

//	springBoot가 자동으로 생성한 ArticleRepository 인터페이스의 bean을 자동으로 주입받는다.
	@Autowired
	private ArticleRepository articleRepository;

//	전체 목록 조회
	public List<Article> index() {
		log.info("ArticleService의 index() 메소드 실행");
		return articleRepository.findAll();
	}

//	단건 조회	
	public Article show(Long id) {
		log.info("ArticleService의 show() 메소드 실행");
		return articleRepository.findById(id).orElse(null);
	}

//	글 저장
	public Article create(ArticleForm form) {
		log.info("ArticleService의 create() 메소드 실행");
		Article article = form.toEntity();
//		id는 JPA가 자동으로 1씩 증가하므로 id가 넘어오는 데이터는 저장하면 안된다.
		if (article.getId() != null) {
			return null;
		}
		return articleRepository.save(article);
	}

//	글 수정
	public Article update(Long id, ArticleForm form) {
		log.info("ArticleService의 update() 메소드 실행");
		Article article = form.toEntity();
		log.info("id: {}, article: {}", id, article.toString());
		Article target = articleRepository.findById(id).orElse(null);
		if (target == null || id != article.getId()) {
			log.info("잘못된 요청! id: {}, article: {}", id, article.toString());
			return null;
		}
		target.patch(article);
		log.info("id: {}, article: {}", id, target.toString());
		Article updated = articleRepository.save(target);
		return updated;
	}

//	글 삭제
	public Article delete(Long id) {
		log.info("id: {}", id);
		Article target = articleRepository.findById(id).orElse(null);
		if (target == null) {
			log.info("잘못된 요청! id가 {}인 데이터가 없습니다.", id);
			return null;
		}
		log.info("id가 {}인 데이터 삭제 완료!!", id);
		articleRepository.delete(target);
		return target;
	}
	
}














