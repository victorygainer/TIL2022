package com.tjoeun.springBoot.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tjoeun.springBoot.dto.ArticleForm;
import com.tjoeun.springBoot.entity.Article;
import com.tjoeun.springBoot.repository.ArticleRepository;
import com.tjoeun.springBoot.service.ArticleService;

import lombok.extern.slf4j.Slf4j;

//	@RestController 어노테이션은 REST api용 컨트롤러로 사용됨을 의미한다.
//	뷰 템플릿 형식이 아닌 json 형식의 데이터를 반환한다.
@RestController
@Slf4j
public class ArticleApiController {

//	ArticleApiController에서 만들어 사용하던 ArticleRepository는 Service 클래스로 넘기고
//	ArticleRepository는 Service 클래스 객체를 만들어 사용한다.
	@Autowired
	private ArticleRepository articleRepository;
//	springBoot가 자동으로 생성한 ArticleService 클래스의 bean을 자동으로 주입받는다.
	@Autowired
	private ArticleService articleService;
	
//	전체 목록 조회
	@GetMapping("/api/articles")
	public List<Article> index() {
		log.info("ArticleApiController의 index() 메소드 실행");
//		return articleRepository.findAll();
		return articleService.index();
	}
	
//	단건 조회
	@GetMapping("/api/articles/{id}")
	public Article show(@PathVariable Long id) {
		log.info("ArticleApiController의 show() 메소드 실행");
//		return articleRepository.findById(id).orElse(null);
		return articleService.show(id);
	}
	
//	글 저장
	@PostMapping("/api/articles")
//	form에서 데이터를 받아올 때는 커맨드 객체로 그냥 받으면 되지만 REST api에서 json으로 던지는
//	데이터를 받을 때는 body 부분에 담겨오는 데이터를 받아야 하므로 커맨드 객체에서 @RequestBody
//	어노테이션을 붙여서 받아야 한다.
//	상태 코드를 담아서 리턴하려면 ResponseEntity 객체를 사용한다.
//	ResponseEntity<Article>를 리턴 타입으로 사용하려면 ResponseEntity 객체에 Article 객체를 
//	담아서 리턴한다.
	public ResponseEntity<Article> create(@RequestBody ArticleForm form) {
		log.info("ArticleApiController의 create() 메소드 실행");
		log.info(form.toString());
		
//		Article saved = articleRepository.save(form.toEntity());
		Article saved = articleService.create(form);
		
//		HttpStatus.CREATED: 201, HttpStatus.BAD_REQUEST: 400
//		return ResponseEntity.status(HttpStatus.CREATED).body(saved);
//		body() 메소드는 body에 데이터를 담아서 넘기고 build() 메소드는 body 없이 넘겨준다.
		return saved != null ?
				ResponseEntity.status(HttpStatus.CREATED).body(saved) :
				ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
	}
	
//	글 수정
	@PatchMapping("/api/articles/{id}")
	public ResponseEntity<Article> update(@PathVariable Long id, @RequestBody ArticleForm form) {
		log.info("ArticleApiController의 update() 메소드 실행");
		/*
//		수정용 Entity를 생성한다.
		Article article = form.toEntity(); // 수정할 정보
		log.info("id: {}, article: {}", id, article.toString());
		
//		수정할 Entity를 조회한다.
		Article target = articleRepository.findById(id).orElse(null); // 수정할 원본
//		잘못된 요청(수정할 대상이 없거나 id가 다른 경우)을 처리한다.
		if (target == null || id != article.getId()) {
//			400, 잘못된 요청 응답
			log.info("잘못된 요청! id: {}, article: {}", id, article.toString());
//			ResponseEntity 객체에 400 상태 코드를 저정하고 body에는 아무것도 저장하지 않는다.
//			HttpStatus.BAD_REQUEST: 400
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
		}
		
//		수정 후 정상 응답을 보낸다.
//		RequestBody를 통해 ArticleForm으로 넘어오는 수정할 데이터의 일부가 넘어오지 않을 경우 넘어오지
//		않은 데이터는 null로 수정되는 문제가 발생된다. 이 현상을 방지하기 위해서 조회된 수정할 Entity를
//		RequestBody를 통해 넘어온 데이터가 있는 경우만 수정한다.
		target.patch(article); // 수정할 원본을 수정할 정보로 수정한다.
		log.info("id: {}, article: {}", id, target.toString());
		Article updated = articleRepository.save(target);
		*/
		Article updated = articleService.update(id, form);
		
//		ResponseEntity 객체에 200 상태 코드를 저정하고 body에는 수정된 데이터를 저장한다.
//		HttpStatus.OK: 200, HttpStatus.BAD_REQUEST: 400
//		return ResponseEntity.status(HttpStatus.OK).body(updated);
		return updated != null ?
				ResponseEntity.status(HttpStatus.OK).body(updated) :
				ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
	}
	
//	글 삭제
	@DeleteMapping("/api/articles/{id}")
	public ResponseEntity<Article> delete(@PathVariable Long id) {
		log.info("ArticleApiController의 delete() 메소드 실행");
		/*
		log.info("id: {}", id);
//		삭제할 Entity를 조회한다.
		Article target = articleRepository.findById(id).orElse(null);
//		잘못된 요청(수정할 대상이 없을 경우)을 처리한다.
		if (target == null) {
//			400, 잘못된 요청 응답
			log.info("잘못된 요청! id가 {}인 데이터가 없습니다.", id);
//			ResponseEntity 객체에 400 상태 코드를 저정하고 body에는 아무것도 저장하지 않는다.
//			HttpStatus.BAD_REQUEST: 400
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
		}
//		삭제 후 정상 응답을 보낸다.
		log.info("id가 {}인 데이터 삭제 완료!!", id);
		articleRepository.delete(target);
		*/
		Article deleted = articleService.delete(id);

//		ResponseEntity 객체에 204 상태 코드를 저정하고 body에는 수정된 데이터를 저장한다.
//		HttpStatus.NO_CONTENT: 204, HttpStatus.BAD_REQUEST: 400
//		return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
		return deleted != null ?
				ResponseEntity.status(HttpStatus.NO_CONTENT).build() :
				ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
	}
	
}










