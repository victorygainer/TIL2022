package com.tjoeun.springBoot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.tjoeun.springBoot.dto.ArticleForm;
import com.tjoeun.springBoot.entity.Article;
import com.tjoeun.springBoot.repository.ArticleRepository;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j // 롬복에서 지원하는 로그 출력 어노테이션
public class ArticleController {

//	JPA repository 인터페이스(ArticleRepository) 객체를 선언하고 @Autowired 어노테이션으로 초기화 한다.
	@Autowired // springboot가 미리 생성해놓은 객체(bean)을 가져다 자동으로 연결한다.
	private ArticleRepository articleRepository;
	
	@GetMapping("/articles/new")
	public String newArticleForm() {
//		System.out.println("ArticleController의 newArticleForm() 메소드 실행");
//		@Slf4j 어노테이션 로그 레벨, ()안에는 반드시 문자열만 사용할 수 있다.
//		log.trace(): 가장 자세한 로그
//		log.warn(): 경고 로그
//		log.info(): 정보성 로그
//		log.debug(): 디버깅용 로그
//		log.error(): 에러 로그
		log.info("ArticleController의 newArticleForm() 메소드 실행");
		
		return "articles/new";
	}
	
	@PostMapping("/articles/create")
//	form에서 넘어오는 데이터는 커맨드 객체로 받는다.
	public String createArticle(ArticleForm form) {
//		System.out.println("ArticleController의 createArticle() 메소드 실행");
		log.info("ArticleController의 createArticle() 메소드 실행");
//		System.out.println(form);
		log.info(form.toString());
		
//		form에 입력된 데이터를 받아 데이터베이스에 저장하는 코드를 추가한다.
//		DTO 데이터를 Entity로 변환한다.
		Article article = form.toEntity();
//		System.out.println(article);
		log.info(article.toString());
//		repository에게 Entity를 데이터베이스에 저장하게 한다.
//		id가 자동으로 생성된다.
		Article saved = articleRepository.save(article);
//		System.out.println(saved);
		log.info(saved.toString());
		
		return "articles/new";
	}
	
}
