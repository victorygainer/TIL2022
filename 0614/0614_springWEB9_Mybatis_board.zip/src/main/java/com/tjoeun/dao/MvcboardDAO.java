package com.tjoeun.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;

import com.tjoeun.springWEB6_DBCPTemplate_board.Constant;
import com.tjoeun.vo.MvcboardVO;

public class MvcboardDAO {

	private JdbcTemplate template;
	public MvcboardDAO() {
		template = Constant.template;
	}
	
	public void insert(final MvcboardVO mvcboardVO) {
		System.out.println("MvcboardDAO의 insert() 메소드 실행");
		String sql = "insert into mvcboard (idx, name, subject, content, gup, lev, seq) " +
				"values (mvcboard_idx_seq.nextval, ?, ?, ?, mvcboard_idx_seq.currval, 0, 0)";
		template.update(sql, new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, mvcboardVO.getName());
				ps.setString(2, mvcboardVO.getSubject());
				ps.setString(3, mvcboardVO.getContent());
			}
		});
	}

	public int selectCount() {
		System.out.println("MvcboardDAO의 selectCount() 메소드 실행");
		String sql = "select count(*) from mvcboard";
		return template.queryForInt(sql);
	}

	public ArrayList<MvcboardVO> selectList(HashMap<String, Integer> hmap) {
		System.out.println("MvcboardDAO의 selectList() 메소드 실행");
		String sql = "select * from (" + 
	             "    select rownum rnum, AA.* from (" +
	             "        select * from mvcboard order by gup desc, seq asc" +
	             "    ) AA where rownum <= " + hmap.get("endNo") +
	             ") where rnum >= " + hmap.get("startNo");
		return (ArrayList<MvcboardVO>) template.query(sql, new BeanPropertyRowMapper(MvcboardVO.class));
	}

	public void increment(final int idx) {
		System.out.println("MvcboardDAO의 increment() 메소드 실행");
		String sql = "update mvcboard set hit = hit + 1 where idx = " + idx;
		template.update(sql);
	}

	public MvcboardVO selectByIdx(int idx) {
		System.out.println("MvcboardDAO의 selectByIdx() 메소드 실행");
		String sql = "select * from mvcboard where idx = " + idx;
		return template.queryForObject(sql, new BeanPropertyRowMapper(MvcboardVO.class));
	}

	public void update(final int idx, final String subject, final String content) {
		System.out.println("MvcboardDAO의 update(int idx, String subject, String content) 메소드 실행");
		String sql = "update mvcboard set subject = ?, content = ? where idx = ?";
		template.update(sql, new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, subject);
				ps.setString(2, content);
				ps.setInt(3, idx);
			}
		});
	}

	public void update(final MvcboardVO mvcboardVO) {
		System.out.println("MvcboardDAO의 update(MvcboardVO mvcboardVO) 메소드 실행");
		String sql = "update mvcboard set subject = ?, content = ? where idx = ?";
		template.update(sql, new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, mvcboardVO.getSubject());
				ps.setString(2, mvcboardVO.getContent());
				ps.setInt(3, mvcboardVO.getIdx());
			}
		});
	}

	public void delete(final int idx) {
		System.out.println("MvcboardDAO의 delete() 메소드 실행");
		String sql = "delete from mvcboard where idx = " + idx;
		template.update(sql);
	}

	public void replyIncrement(final HashMap<String, Integer> hmap) {
		System.out.println("MvcboardDAO의 replyIncrement() 메소드 실행");
		String sql = "update mvcboard set seq = seq + 1 where gup = ? and seq >= ?";
		template.update(sql, new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setInt(1, hmap.get("gup"));
				ps.setInt(2, hmap.get("seq"));
			}
		});
	}

	public void replyInsert(final MvcboardVO mvcboardVO) {
		System.out.println("MvcboardDAO의 replyInsert() 메소드 실행");
		String sql = "insert into mvcboard (idx, name, subject, content, gup, lev, seq) " +
				"values (mvcboard_idx_seq.nextval, ?, ?, ?, ?, ?, ?)";
		template.update(sql, new PreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement pstmt) throws SQLException {
				pstmt.setString(1, mvcboardVO.getName());
				pstmt.setString(2, mvcboardVO.getSubject());
				pstmt.setString(3, mvcboardVO.getContent());
				pstmt.setInt(4, mvcboardVO.getGup());
				pstmt.setInt(5, mvcboardVO.getLev());
				pstmt.setInt(6, mvcboardVO.getSeq());
			}
		});
	}

}







