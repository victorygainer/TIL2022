package com.tjoeun.springBoot.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller // 이 클래스는 컨트롤러로 사용되는 클래스임을 springBoot에게 알려준다.
public class FirstController {

//	브라우저에 "/hi"라는 요청이 들어오면 niceToMeetYou() 메소드가 실행된다.
	@GetMapping("/hi")
	public String niceToMeetYou() {
		System.out.println("컨트롤러의 niceToMeetYou() 메소드 실행");
		return "greetings"; // viewpage 이름
	}
	
}
